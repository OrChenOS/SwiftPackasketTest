//
//  FruitBasket.h
//  FruitBasket
//
//  Created by Or Chen on 08/08/2021.
//

#import <Foundation/Foundation.h>

//! Project version number for FruitBasket.
FOUNDATION_EXPORT double FruitBasketVersionNumber;

//! Project version string for FruitBasket.
FOUNDATION_EXPORT const unsigned char FruitBasketVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FruitBasket/PublicHeader.h>


